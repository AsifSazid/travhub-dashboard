<?php
include_once('./authenticate.php');
$ip_port = @file_get_contents('../ippath.txt');
if (empty($ip_port)) {
    $ip_port = "http://103.104.219.3:898";
}

$clientId = $_GET['client_id'];


// $showClientApi = $ip_port . "api/clients/show.php";
$getClientsWorksApi = $ip_port . "api/works/client-works.php?client_id=$clientId";
$getClientFinEntriesApi = $ip_port . "api/financial_entries/fin-entries.php?id=$clientId";
$createWorkApi = $ip_port . "api/works/client-work-store.php?cid=$clientId";
$storeWorkApi = $ip_port . "api/works/store.php";
$getClient = $ip_port . "api/clients/get-client.php?cid=$clientId";
// $getClientFinEntriesApi = $ip_port . "api/financial_entries/client-fin-entries.php?client_id=$clientId";

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complete Work Entry</title>
    <link rel="icon" type="image/png" href="../assets/images/logo/round-logo.png" sizes="16x16">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://unpkg.com/sortablejs@1.14.0/Sortable.min.js"></script>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        /* Tab Styles */
        .tab-button {
            padding: 12px 20px;
            font-weight: 500;
            border-bottom: 3px solid transparent;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            white-space: nowrap;
        }

        .tab-button:hover {
            background-color: #f8fafc;
            border-color: #e2e8f0;
        }

        .tab-button.active {
            color: #3b82f6;
            border-color: #3b82f6;
            background-color: #eff6ff;
        }

        .tab-button.active::after {
            content: '';
            position: absolute;
            bottom: -3px;
            left: 0;
            width: 100%;
            height: 3px;
            background-color: #3b82f6;
        }

        .tab-content {
            display: none;
            animation: fadeIn 0.3s ease;
        }

        .tab-content.active {
            display: block;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>

<body class="bg-gray-50 font-sans">
    <script>
        const IP_PATH = `<?php echo $ip_port; ?>`;
        const GET_CLIENT_INFO_API = "<?php echo $getClient; ?>";

        let clientName = '';
        
        // ==================== FETCH CLIENT DATA ====================
    
        async function fetchClientData() {
            try {
                const response = await fetch(GET_CLIENT_INFO_API);
                if (!response.ok) throw new Error('Network response was not ok');
                const data = await response.json();
                clientName = data.client.name;
            } catch (error) {
                console.error('Error fetching client data:', error);
            }
        }
        fetchClientData();
    </script>
    
    <!-- Top Navigation -->
    <?php include '../elements/header.php'; ?>

    <!-- Sidebar -->
    <?php include '../elements/aside.php'; ?>

    <!-- Main Content -->
    <main id="mainContent" class="pt-16 pl-0 lg:pl-64 lg:my-16 transition-all duration-300">
        <div class="p-6">
            <div class="bg-white rounded-lg shadow p-4 flex flex-col h-[400px] md:h-[calc(100vh-8rem)]">
                <!-- Header -->
                <div class="mb-6">
                    <h2 class="text-lg font-semibold text-gray-800 flex items-center">
                        <i class="fas fa-user-circle mr-2 text-purple-600"></i>
                        Client's Profile
                    </h2>
                    <p class="text-sm text-gray-600">Manage traveler information, documents, and related data</p>
                </div>

                <!-- Tabs Navigation -->
                <div class="border-b border-gray-200 mb-6">
                    <div class="flex space-x-1 overflow-x-auto custom-scrollbar">
                        <button class="tab-button flex items-center active" data-tab="details">
                            <i class="fas fa-folder mr-2"></i>
                            Details
                        </button>
                        <button class="tab-button flex items-center" data-tab="documents">
                            <i class="fas fa-folder mr-2"></i>
                            Documents
                        </button>
                        <button class="tab-button flex items-center" data-tab="information">
                            <i class="fas fa-info-circle mr-2"></i>
                            Information
                        </button>
                        <button class="tab-button flex items-center" data-tab="work-board">
                            <i class="fas fa-clipboard-list mr-2"></i>
                            Work Board
                        </button>
                        <button class="tab-button flex items-center" data-tab="accounting">
                            <i class="fas fa-calculator mr-2"></i>
                            Accounting
                        </button>
                        <button class="tab-button flex items-center" data-tab="credentials">
                            <i class="fas fa-key mr-2"></i>
                            Credentials
                        </button>
                        <button class="tab-button flex items-center" data-tab="negotiations">
                            <i class="fa-solid fa-handshake mr-2"></i>
                            Negotiations
                        </button>
                    </div>
                </div>

                <!-- Tab Content Area -->
                <div class="flex-1 overflow-y-auto">
                    <!-- Details Tab -->
                    <div id="details" class="tab-content active">
                        <div class="grid grid-cols-3 gap-6 h-full">
                            <div class="col-span-2 h-full">
                                <div class="text-center">
                                    <i class="fas fa-folder text-4xl text-blue-500 mb-4"></i>
                                    <h3 class="text-xl font-semibold mb-2">Traveller Management</h3>
                                    <p class="text-gray-600">Traveller management will be displayed here</p>

                                    <hr class="my-8">

                                    <div>
                                        Traveller Group
                                    </div>
                                </div>
                            </div>
                            <div class="flex items-center justify-center h-full border-l border-gray-400">
                                <div class="text-center">
                                    <i class="fas fa-folder text-4xl text-blue-500 mb-4"></i>
                                    <h3 class="text-xl font-semibold mb-2">Client Profile</h3>
                                    <p class="text-gray-600">Client Profile management will be displayed here</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Documents Tab -->
                    <div id="documents" class="tab-content active">
                        <div class="grid grid-cols-2 gap-6 h-full">
                            <div class="col-span-2 justify-center h-full w-full">
                                <div class="text-center">
                                    <?php include('sc-documents.php') ?> <!-- sc means show client -->
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Information Tab -->
                    <div id="information" class="tab-content">
                        <div class="grid grid-cols-2 gap-6 h-full">
                            <div class="col-span-2 justify-center h-full w-full">
                                <div class="text-center">
                                    <h3 class="text-xl font-semibold mb-2">Information</h3>

                                    <?php include('sc-informations.php') ?> <!-- sc means show client -->
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Work Board Tab -->
                    <div id="work-board" class="tab-content">
                        <div class="grid grid-cols-2 gap-6 h-full">
                            <div class="col-span-2 justify-center h-full w-full">
                                <div class="text-center">
                                    <?php include('sc-works.php') ?> <!-- sc means show client -->
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Accounting Tab -->
                    <div id="accounting" class="tab-content">
                        <div class="grid grid-cols-2 gap-6 h-full">
                            <div class="col-span-2 justify-center h-full w-full">
                                <div class="text-center">
                                    <?php include('sc-accounting.php') ?> <!-- sc means show client -->
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Linked Travellers Tab -->
                    <div id="linked-travellers" class="tab-content">
                        <div class="h-full w-full">
                            <?php include('tp-linked-travellers.php') ?> <!-- sc means show client -->
                        </div>
                    </div>

                    <!-- Credentials Tab -->
                    <div id="credentials" class="tab-content">
                        <div class="h-full w-full">
                            <?php include('credentials.php') ?> <!-- sc means show client -->
                        </div>
                    </div>

                    <!-- Negotiations Tab -->
                    <div id="negotiations" class="tab-content">
                        <div class="h-full w-full">
                            <?php include('sc-negotiations.php') ?> <!-- sc means show client -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Floating Quick Access Tab -->
    <?php include '../elements/floating-menus.php'; ?>

    <script src="../assets/js/script.js?time=<?php echo time(); ?>"></script>

    <script>
        // Tab switching functionality
        document.addEventListener('DOMContentLoaded', function() {
            const tabButtons = document.querySelectorAll('.tab-button');
            const tabContents = document.querySelectorAll('.tab-content');

            // Function to switch tabs
            function switchTab(tabId) {
                // Remove active class from all tabs
                tabButtons.forEach(button => {
                    button.classList.remove('active');
                });

                tabContents.forEach(content => {
                    content.classList.remove('active');
                });

                // Add active class to clicked tab
                const activeButton = document.querySelector(`[data-tab="${tabId}"]`);
                const activeContent = document.getElementById(tabId);

                if (activeButton && activeContent) {
                    activeButton.classList.add('active');
                    activeContent.classList.add('active');
                }
            }

            // Add click event to tab buttons
            tabButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const tabId = this.getAttribute('data-tab');
                    switchTab(tabId);
                });
            });

            // Initialize first tab as active
            if (tabButtons.length > 0) {
                const firstTabId = tabButtons[4].getAttribute('data-tab');
                switchTab(firstTabId);
            }
        });
    </script>
</body>

</html>